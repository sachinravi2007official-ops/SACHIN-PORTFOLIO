# R. Sachin — Personal Portfolio

A responsive, single-file portfolio website with a dark futuristic 3D glassmorphism look.

## Run it
1. Extract this ZIP.
2. Open the `sachin-portfolio` folder in Visual Studio Code.
3. Open `index.html`.
4. To preview, right-click `index.html` and choose **Open with Live Server** if you have the Live Server extension installed. Alternatively, double-click `index.html` in File Explorer to open it in your browser.

## Personalize it
- Search in `index.html` for `R. Sachin` to edit the name/text.
- Replace the GitHub and LinkedIn placeholder URLs in the Contact section with your own profile URLs.
- Replace `href="mailto:"` with your email, for example `href="mailto:you@example.com"`.
- Edit the Skills section to include only skills you have started learning or can demonstrate.
- Edit project descriptions as your projects become real and ready to showcase.

The website uses plain HTML, CSS, and JavaScript. No build step or framework is required. Google Fonts needs an internet connection; the page still works without it using fallback fonts.
